cinemas = getCinemas();
function getInfo(){
    let searchBar = window.location.search.substring(1);
    let final_string = searchBar.split("&")[0].split("=")[1].split("_");
    ticket_info = searchBar.split("&")[1].split("=")[1].split("+");
    ticket_info.sort();
    ticket_info.shift();
    id_num = final_string[0];
    movie_name = final_string[1];
    for(i = 0; i < cinemas.length; i++){
        let subArray1 = cinemas[i].movies;
        for(j = 0; j < subArray1.length; j++){
            let subArray2 = subArray1[j].shows;
            for(k = 0; k < subArray2.length; k++){
                if(subArray2[k].index == id_num){
                    cinema_name = cinemas[i].branchName;
                    date_time = subArray2[k].datetime;
                    house_num = subArray2[k].house;
                    break;
                }
            }
        }
    }
}

function changeInfo(){
    let array_source1 = new Array("Cinema", "Movie", "Date", "Time", "House");
    let array_source2 = new Array(cinema_name, movie_name, date, time, house_num);
    txt = "<h2>Ticket Info</h2>"
    for(i = 0; i < ticket_info.length; i++){
        txt += "<div>";
        for(j = 0; j < array_source1.length; j++){
            txt += `<p class="new_line"> <span class="special_info1">` + array_source1[j] + `</span> <span class="colon">:</span> <span class="special_info2">` + array_source2[j] + `</span></p>`
        }
        txt += `<p class="new_line"> <span class="special_info1"> Seat </span> <span class="colon">:</span> <span class="special_info2">` + ticket_info[i] + `</span></p><br> </div>`;
    }
    document.querySelector("section").innerHTML = txt;
}

function correctInfo(){
    getInfo();
    movie_name = movie_name.split("+").join(" ");
    date_time = date_time.split(" - ");
    date = date_time[0];
    time = date_time[1];
    changeInfo();
}

function init(){
    correctInfo();
}
window.onload = init;