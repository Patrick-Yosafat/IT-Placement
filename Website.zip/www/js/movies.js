function getMovies() {
    return [
        {
            id:1,
            type:"now",
            thumbnail:"image/the_falling_giant.png",
            src:"https://courses.cs.cityu.edu.hk/cs2204/example/video/BigBuck.mp4",
            name:"The Falling Giant",
            cast:"Nandogy, Hansgro",
            director:"Reyfel",
            duration: 106
        },
        {
            id:2,
            type:"now",
            thumbnail:"image/foxie_and_the_magical_forest.png",
            src:"https://courses.cs.cityu.edu.hk/cs2204/example/video/nature.mp4",
            name:"Foxie and The Magical Forest",
            cast:"Cindooyooo, Darbone, Chelle, Babonie",
            director:"Adrienn",
            duration: 116
        },
        {
            id:3,
            type:"now",
            thumbnail:"image/cartoon_coffees.png",
            src:"https://courses.cs.cityu.edu.hk/cs2204/example/video/bear.mp4",
            name:"Cartoon Coffees",
            cast:"Kanizong, Yowils, Nepnop",
            director:"Moookkyy",
            duration: 120
        },
        {
            id:4,
            type:"upcoming",
            thumbnail:"image/fire_box.png",
            src:"https://courses.cs.cityu.edu.hk/cs2204/example/video/wonders.mp4",
            name:"Fire Box",
            cast:"Harisunday, Bebekcerewet, Brygreen",
            director:"Denong",
            duration: 112
        },
        {
            id:5,
            type:"upcoming",
            thumbnail:"image/juturn-the_galaxyship.png",
            src:"https://courses.cs.cityu.edu.hk/cs2204/example/video/trailer.mp4",
            name:"Juturn: The Galaxyship",
            cast:"Atteelo, Yosy, Chopchop, Felicim",
            director:"Joandrothomas",
            duration: 113
        },
        {
            id:6,
            type:"upcoming",
            thumbnail:"image/delightful_afternoon.png",
            src:"http://courses.cs.cityu.edu.hk/cs2204/video/casablanca-s.mp4",
            name:"Delightful Afternoon",
            cast:"Yosinu, Richaa, Hicaa, Timkentang, Neilaki, Estehlaa, Eigentan, Georbry",
            director:"Michjose",
            duration: 120
        }
    ]
}
