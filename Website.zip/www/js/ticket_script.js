cinemas = getCinemas();
        seat_info = "";
        function getInfo(){
            let searchBar = window.location.search.substring(1);
            let final_string = searchBar.split("&")[1].split("=")[1].split("_");
            id_num = final_string[0];
            movie_name = final_string[1];
            for(i = 0; i < cinemas.length; i++){
                let subArray1 = cinemas[i].movies;
                for(j = 0; j < subArray1.length; j++){
                    let subArray2 = subArray1[j].shows;
                    for(k = 0; k < subArray2.length; k++){
                        if(subArray2[k].index == id_num){
                            cinema_name = cinemas[i].branchName;
                            date_time = subArray2[k].datetime;
                            house_num = subArray2[k].house;
                            break;
                        }
                    }
                }
            }
        }

        function changeInfo(){
            let array_target = document.querySelectorAll(".special_info2");
            let array_source = new Array(cinema_name, movie_name, date, time, house_num);
            for(i = 0; i < array_target.length; i++){
                array_target[i].innerHTML = array_source[i];
            }
            document.querySelector("#info_pass").value = id_num + "_" + movie_name;
        }

        function correctInfo(){
            getInfo();
            movie_name = movie_name.split("+").join(" ");
            date_time = date_time.split(" - ");
            date = date_time[0];
            time = date_time[1];

            changeInfo();
        }
        
        function checkSeat(){
            let tableData = document.querySelectorAll("td");
            tableData.forEach(item => {
                item.addEventListener('click', event => {
                    if(item.querySelector("input")){
                        seat = item.querySelector("input");
                        if(!seat.check){
                            seat.check = true;
                            seat.disabled = true;
                            txt = item.querySelector("label");
                            txt.style.color = "#FDFFA9";
                            txt.style.fontWeight = "bold";
                            txt.style.backgroundColor = "#00C897";
                            seat_info += seat.value + " ";
                            document.querySelector("#seat_info").innerHTML = seat_info.slice(0, -1);
                            document.querySelector("#info_seat").setAttribute("value", seat_info);
                        }
                    }
                });
            });
        }

        function init(){
            correctInfo();
            checkSeat();
        }
        window.onload = init;
