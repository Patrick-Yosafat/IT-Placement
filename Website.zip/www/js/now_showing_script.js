movies = getMovies();
        cinemas = getCinemas();
        function set_cinema(){
            let txtCinema = "";
            for(i = 0; i < cinemas.length; i++){
                txtCinema += `<option value="` + i + `">` + cinemas[i].branchName + `</option>`;
            }
        return txtCinema;
        }

        function get_id(){
            change_cinemas(this.value);
        }

        function change_cinemas(id_num){
            let txtSelect = "";
            let movies_num = cinemas[id_num].movies;
            for(i = 0; i < movies_num.length; i++){
                let show_num = movies_num[i].shows;
                let movie_name = movies[(movies_num[i].id-1)].name;
                let movie_pic = movies[(movies_num[i].id-1)].thumbnail;
                for(j = 0; j < show_num.length; j++){
                    txtSelect += `<div class="column">`;
                        txtSelect += `<input type="radio" name="shows" value="` + show_num[j].index + `_` + movie_name + `"> <br>`;
                        txtSelect += `<label for="shows">` + movie_name + `</label> <br>`;
                        txtSelect += `<img src="../` + movie_pic + `" alt="` + movie_name + ` Thumbnail" title=` + movie_name + ` Thumbnail"> <br>`;
                        txtSelect += `<p> Date & Time: ` + show_num[j].datetime + `</p>`;
                        txtSelect += `<p> House: ` + show_num[j].house + `</p>`;
                    txtSelect += `</div>`;
                }
            }
            document.querySelector(".three_columns").innerHTML=txtSelect;
        }

        
        function init(){
            document.querySelector("#movie_cinema").innerHTML = set_cinema();
            change_cinemas(0);
            document.querySelector("#movie_cinema").onchange = get_id;
        }
        window.onload = init;