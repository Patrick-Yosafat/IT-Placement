#include <iostream>
using namespace std;

//node class that will be the stored object of the heap, just a simple class that divides the work in the heap class
class Node {
private:
	Node* left = NULL;
	Node* right = NULL;
	int height = 0; //the height property is important for finding the weighted length of the huffman tree
	int value;
public:
	Node() {
		value = 0;
	}

	Node(int v) {
		value = v;
	}

	Node(int v, Node* l, Node* r) {
		left = l;
		right = r;
		value = v;
	}
	void plusHeight() { height += 1; }
	void setValue(int v) { value = v; }
	int getHeight() { return height; }
	int getValue() { return value; }
	Node* getLeft() { return left; }
	Node* getRight() { return right; }
};

//manually create a minheap class and its operations like pop, print, insert, and isEmpty
class Heap {
private:
	Node** tree;
	int size;
public:
	Heap(int num) {
		tree = new Node*[num];
		size = 0;
	}
	void insert(Node* n);
	Node* pop();
	void print() {
		for (int i = 0; i < size; i++) {
			cout << tree[i]->getValue() << " ";
		}
		cout << endl;
	}
	bool isEmpty() { return size == 0; }
};

void Heap::insert(Node* n) {
	Node* temp;
	tree[size] = n;
	int i = size;
	while (tree[i]->getValue() < tree[(i - 1) / 2]->getValue() && i > 0) {
		temp = tree[i];
		tree[i] = tree[(i - 1) / 2];
		tree[(i - 1) / 2] = temp;
		i = (i - 1) / 2;
	}
	size += 1;
}

Node* Heap::pop() {
	Node* val = tree[0];
	tree[0] = tree[size - 1];
	size -= 1;
	int child;
	Node* temp;
	int i = 0;
	while (true) {
		child = i * 2 + 1;
		if (child + 1 < size && tree[child + 1]->getValue() < tree[child]->getValue()) {
			child += 1;
		}

		if (child < size && tree[child]->getValue() < tree[i]->getValue()) {
			temp = tree[i];
			tree[i] = tree[child];
			tree[child] = temp;
			i = child;
		}
		else {
			break;
		}
	}
	return val;
}

void addHeight(Node* n) {
	if (n->getLeft() == NULL && n->getRight() == NULL) {
		n->plusHeight();
	}
	else {
		if (n->getLeft() != NULL) {
			addHeight(n->getLeft());
		}
		if (n->getRight() != NULL) {
			addHeight(n->getRight());
		}
	}
}

Node* constructNewTree(Node* first, Node* second) {
	int value = first->getValue() + second->getValue();

	//makes the huffman tree keep track of each node's height
	addHeight(first);
	addHeight(second);

	//combine the two smallest elements in heap
	Node* val = new Node(value, first, second);
	return val;
}

Node* createHuffManTree(Heap* heap) {
	Node* result = NULL;
	while (!heap->isEmpty()) {
		Node* node1 = heap->pop();
		Node* node2 = heap->pop();
		result = constructNewTree(node1, node2);
		if (!heap->isEmpty()) {
			//insert the combined node back to the heap
			heap->insert(result);
		}
	}
	return result;
}

//recursion function to get the weighted length of the huffman tree
int huffValue(Node* n) {
	if (n->getLeft() == NULL && n->getRight() == NULL) {
		return n->getValue() * n->getHeight();
	}
	else if (n->getLeft() != NULL && n->getRight() != NULL) {
		return huffValue(n->getLeft()) + huffValue(n->getRight());
	}
	else if (n->getLeft() != NULL) {
		return huffValue(n->getLeft());
	}
	else { //equivalent with: else if (n->getRight() != NULL)
		return huffValue(n->getRight());
	}
}

int main() {
	int num, val;
	Heap* heap;
	while (cin >> num) {
		//before creating a huffman tree, insert all the input numbers into heap
		heap = new Heap(num);
		for (int i = 0; i < num; i++) {
			cin >> val;
			Node* temp = new Node(val);
			heap->insert(temp);
		}

		//create huffman tree based on heap
		Node* root = createHuffManTree(heap);
		if (root != NULL) {
			cout << huffValue(root) << endl;
		}
		//exceptions if huffman tree is empty
		else { 
			cout << 0 << endl;
		}
		
	}
}