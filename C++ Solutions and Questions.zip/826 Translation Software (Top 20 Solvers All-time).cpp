#include <iostream>
using namespace std;

bool hasDuplicate(int* dict, int num, int m) {
	for (int i = 0; i < m; i++) {
		if (dict[i] == num) {
			return true;
		}
	}
	return false;
}

int main() {
	int m, n, num, count;
	count = 0;

	//input m, n
	cin >> m >> n;

	//dictionary initialization
	int* dict = new int[m];
	for (int i = 0; i < m; i++) {
		dict[i] = -1;
	}


	for (int i = 0, j = 0; i < n; i++) {
		cin >> num;

		//if the dictionary doesn't contains num, put it in dictionary & add count
		if (!hasDuplicate(dict, num, m)) {
			j %= m;
			dict[j] = num;
			j++;
			count++;
		}
	}
	cout << count << "\n";
	return 1;
}