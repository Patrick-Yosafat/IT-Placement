#include <iostream>
#define VALUE 100
using namespace std;

class hashTable { // with mid-square method and linear probing open addressing
private:
	long* table;
	unsigned size;
	unsigned maxSize;

public:
	hashTable() {
		// initialization
		table = new long[VALUE];
		for (int i = 0; i < VALUE; i++) {
			table[i] = -1;
		}
		size = 0;
		maxSize = VALUE;
	}
	void Insert(unsigned x);
	bool Delete(unsigned x);
	long* Search(unsigned x);

	void ResizeTable(bool x);
	void print() {
		for (int i = 0; i < maxSize; i++) {
			cout << table[i] << endl;
		}
	}
	unsigned findIndex(unsigned x) {
		return ((x/100) * (x/100) + x) % maxSize;
	}
};

void hashTable::Insert(unsigned x) {
	unsigned index = findIndex(x);
	int counter = 1;
	for (int i = 0; i < maxSize; i++) {
		if (table[i] == x) {
			return;
		}
	}
	while (true) {
		if (table[index] == -1) {
			table[index] = x;
			size += 1;

			if (size > (maxSize / 2)) {
				ResizeTable(true);
			} else if (size < (maxSize / 4) && (maxSize / 4) > 1) {
				ResizeTable(false);
			}
			return;
		}
		index = (index + 1) % maxSize;
		counter += 1;
	}
}

bool hashTable::Delete(unsigned x) {
	long* temp = Search(x);
	if (temp != NULL) {
		*temp = -1;
		size -= 1;

		if (size > (maxSize / 2)) {
			ResizeTable(true);
		}
		else if (size < (maxSize / 4) && (maxSize / 4) > 1) {
			ResizeTable(false);
		}

		return true;
	}
	return false;
}

long* hashTable::Search(unsigned x) {
	unsigned index = findIndex(x);
	for (int i = 1; i < maxSize; i++) {
		if (table[index] == x) {
			return (table + index);
		}
		index = (index + 1) % maxSize;
	}
	return NULL;
}

void hashTable::ResizeTable(bool x) {
	unsigned tempMaxSize = maxSize;
	unsigned tempSize = size;
	unsigned index;
	if (x == true) {
		maxSize *= 2;
	}
	else {
		maxSize /= 4;
	}

	long* temp = table;
	table = new long[maxSize];
	for (unsigned i = 0; i < maxSize; i++) {
		table[i] = -1;
	}

	size = 0;
	for (unsigned i = 0, j = 0; i < tempMaxSize && j < tempSize; i++) {
		if (temp[i] != -1) {
			index = findIndex(temp[i]);
			for (unsigned k = 0; k < maxSize; k++) {
				if (table[index] == -1) {
					table[index] = temp[i];
					j += 1;
					size += 1;
					break;
				}
				index = (index + 1) % maxSize;
			}
		}
	}
}

int main() {
	string opt;
	long val;
	hashTable* h = new hashTable();
	while (cin >> opt) {
		cin >> val;

		if (opt == "search") {
			if (h->Search(val) != NULL) {
				cout << val << " was found" << endl;
			}
			else {
				cout << val << " does not exist" << endl;
			}
		}
		else if (opt == "insert") {
			h->Insert(val);
		}
		else {
			if (h->Delete(val)) {
				cout << val << " was deleted successfully" << endl;
			}
			else {
				cout << val << " does not exist" << endl;
			}
		}
	}
}