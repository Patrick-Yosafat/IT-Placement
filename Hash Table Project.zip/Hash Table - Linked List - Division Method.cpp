#include <iostream>
#define N 100
using namespace std;

class Node {
private:
	long data;
	Node* next;
public:
	Node() {
		data = -1;
		next = NULL;
	}
	Node(long d) {
		data = d;
		next = NULL;
	}
	long getData() { return data; }
	Node* getNext() { return next; }
	void setData(long d) { data = d; }
	void setNext(Node* n) { next = n; }
};

class linkedList {
private:
	Node* root;

public:
	linkedList() {
		root = new Node();
	}

	long getRootData() { return root->getData(); }

	void insert(long d) {
		if (root->getData() == -1) {
			root->setData(d);
		}
		else if (root->getData() != d) {
			Node* current = find(d);
			if (current == NULL) {
				current = new Node(d);
				current->setNext(root);
				root = current;
			}
		}
	}

	bool remove(long d) {
		if (root->getData() == d) {
			if (root->getNext() == NULL) {
				root->setData(-1);
				return true;
			}
			else {
				Node* temp = root->getNext();
				root->setNext(NULL);
				root = temp;
			}
		}
		else {
			Node* current = find(d);
			if (current != NULL) {
				Node* next = current->getNext()->getNext();
				current->getNext()->setNext(NULL);
				current->setNext(next);
				return true;
			}
			else {
				return false;
			}
		}
	}

	Node* find(long d) {
		Node* node = root;
		while (node->getNext() != NULL) {
			if (node->getNext()->getData() == d) {
				return node;
			}
			node = node->getNext();
		}
		return NULL;	
	}
};

class hashTable { // with division method and linked list separate chaining
private:
	linkedList** table;

public:
	hashTable() {
		// initialization
		table = new linkedList*[N];
		for (int i = 0; i < N; i++) {
			table[i] = new linkedList();
		}
	}
	void Insert(unsigned x);
	bool Delete(unsigned x);
	Node* Search(unsigned x);

	unsigned findKey(unsigned x) {
		return ((x/100)*(x/100) + x) % N;
	}
};

void hashTable::Insert(unsigned x) {
	unsigned index = findKey(x);
	table[index]->insert(x);
}

bool hashTable::Delete(unsigned x) {
	unsigned index = findKey(x);
	bool value = table[index]->remove(x);
	if (value) {
		return true;
	}
	return false;
}

Node* hashTable::Search(unsigned x) {
	unsigned index = findKey(x);
	if (table[index]->getRootData() == x) {
		return new Node();
	}
	else {
		return table[index]->find(x);
	}
}

int main() {
	string opt;
	long val;
	hashTable* h = new hashTable();
	while (cin >> opt) {
		cin >> val;

		if (opt == "search") {
			if (h->Search(val) != NULL) {
				cout << val << " was found" << endl;
			}
			else {
				cout << val << " does not exist" << endl;
			}
		}
		else if (opt == "insert") {
			h->Insert(val);
		}
		else {
			if (h->Delete(val)) {
				cout << val << " was deleted successfully" << endl;
			}
			else {
				cout << val << " does not exist" << endl;
			}
		}
	}
}