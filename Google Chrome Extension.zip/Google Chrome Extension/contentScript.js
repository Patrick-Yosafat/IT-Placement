window.onload = () => {
    let head = document.querySelector("head");
    let link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = chrome.runtime.getURL('style.css');
    head.appendChild(link);

    let placeholder = document.querySelector(".dcg-pillbox-container");
    let icons = document.createElement('div');
    console.log(icons);
    let icon_text1 = document.querySelector(".dcg-container").querySelectorAll("div:not([class])")[3].innerHTML;
    icons.innerHTML = icon_text1 +=
    `
    <div class="switch-variable">
        <div class="dcg-tooltip-hit-area-container" handleevent="true" ontap>
            <div class="dcg-btn-flat-gray dcg-button-1" role="button" tabindex="0" aria-label="Switch Variables" ontap style="background:#ededed">
                <i class="dcg-icon-switch" aria-hidden="true">
                    
                </i>
            </div>
        </div>
    </div>
    `;
}